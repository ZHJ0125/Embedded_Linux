#include <stdio.h>
int main()
{
	//printf("HelloWorld\n");
	getchar();
	return 0;
}
